# supervisor-32： 32位监控程序（“龙芯杯”个人赛）

LA版功能和过程与MIPS差不多，请参考MIPS版介绍